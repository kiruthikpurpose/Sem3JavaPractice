public class FormattedReport {
    public static void main(String[] args) {
        // Using System.out.println to print each item on a new line
        System.out.println("Item: Item1\tQuantity: 10\tPrice: $15.99");
        System.out.println("Item: Item2\tQuantity: 20\tPrice: $25.99");
        System.out.println("Item: Item3\tQuantity: 30\tPrice: $35.99");
    }
}
